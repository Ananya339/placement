<?php
include "dbconfig.php";
if(isset($_POST['submit'])){  // Use $_POST instead of $_post
    $company_name = $_POST['company_name'];
	$filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $folder = "./companylogo/" . $filename;
	$sql3= "INSERT INTO companylogo (company_name, image_path) VALUES ('$company_name','$filename')";	
    if((move_uploaded_file($tempname,$folder))&&(mysqli_query($conn, $sql3)))	{
	echo"
<script>		
window.alert('Logo successfully added!');
window.location.href = 'logo.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);  // Display the actual MySQL error for debugging
    }
}
mysqli_close($conn);
?>	
    