<html>
<head>
<title>PlacementOffice</title>
</head>
<body>
<h1><center>WELCOME BACK TO PLACEMENT WEBSITE!!!</h1>
<center><input type="radio" name="placementoffice" value="CompVistForm" onclick="window.location.href = 'compvisitform.php'";>Company Visit Form <br>
<center><input type="radio" name="placementoffice" value="StudentsPlaced" onclick="window.location.href = 'office_dis.php'";>Placed Students Details <br>
<center><input type="radio" name="placementoffice" value="TVComp" onclick="window.location.href = 'tvcomp.php'";>Company Vist TV Display <br>
<center><input type="radio" name="placementoffice" value="TVDisp" onclick="window.location.href = 'TVDisp.php'";>Placed Student TV Display<br>