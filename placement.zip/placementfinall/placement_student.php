<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placed Students Details</title>
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet">
	 <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	     <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
		    <link href="css/sb-admin-2.min.css" rel="stylesheet">
			<style>
        body {
            font-family: "Times New Roman",Times,serif;
            text-align: center;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 50px;
            max-height: 50px;
        }

        .search-container {
            text-align: right;
        }

        h1 {
            text-align: center;
        }
		.dropbtn{
			background-color:#4CAF50;
			color:white;
			padding:16px;
			font-size:16px;
			border:none;
			cursor:pointer;
		}
		.dropdown{
			position:relative;
			display:inline-block;
		}
		.dropdown-content{
			display:none;
			position:absolute;
			background-color:#f9f9f9;
			min-width:160px;
			box-shadow:0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index:1;
		}
		.drop-content a{
			color:black;
			padding 12px 16px;
			text-decoration:none;
			display:block;
		}
		.dropdown:hover .dropdown-content{
			display:block;
		}
		.dropdown:hover .dropbtn{
			background-color:#3e8e41;
		}
    </style>
</head>

<body id="page-top">



    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="placement_main.php">
                
                <div class="sidebar-brand-text mx-3">Welcome, Placement Office</div>
            </a>
			<hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
<li class="nav-item active">
                <a class="nav-link" href="placement_main.php">
                   
                    <span>Dashboard</span></a>
            </li>
			<li class="nav-item active">
                <a class="nav-link" href="placement_student.php">
                   
                    <span>Placed student details</span></a>
            </li>
			<li class="nav-item active">
                <a class="nav-link" href="tvcomp.php">
                   
                    <span>TV display for company visit</span></a>
            </li>
			<li class="nav-item active">
                <a class="nav-link" href="tvdisplay.php">
                   
                    <span>TV display with placed students details</span></a>
            </li>
			<li class="nav-item active">
                <a class="nav-link" href="logo.php">
                   
                    <span>Add new company logo</span></a>
            </li>
			
            <hr class="sidebar-divider">

            <li class="nav-item">
               
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                    </div>
                </div>
            </li>

        </ul>     
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav  class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
				<h3 text align="center">Placed Students Details</h3>
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <ul class="navbar-nav ml-auto">

						<div class="dropdown">
					<button class="dropbtn">Department</button>
					<div class="dropdown-content">
					<a href="cse_placedstudents.php">CSE</a>
					<br>
					<a href="cse_aiml_placedstudents.php">CSE-AIML</a><br>
					<a href="cse_aids_placedstudents.php">AI& DS</a><br>
					<a href="ise_placedstudents.php">ISE</a><br>
					<a href="ece_placedstudents.php">ECE</a><br>
					<a href="eee_placedstudents.php">EEE</a><br>
					</div>
					</div>
                       <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Placement Office</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                              
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout_placement.php">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
				<button type="button" onclick="window.location.href = 'placement_notice.php'">To take print for notice board click here</button>
    <div class="container">
        <h3>Placed Students Details</h3>
        <table id="placedStudentsTable">
            <thead>
                <tr>
                    <th>Sl. No</th>
                    <th>Name</th>
                    <th>USN</th>
                    <th>Branch</th>
                    <th>Company Name</th>
                    <th>Salary</th>
                    <th>Offer Letter</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include "dbconfig.php";
                $sql = "SELECT s.Name, s.Dept, o.USN, o.CompanyName, o.Package, o.offer_letter
                        FROM offer_letter o
                        INNER JOIN student s ON o.USN = s.USN
                        WHERE o.status=1";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    $counter = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $counter . "</td>";
                        echo "<td>" . $row["Name"] . "</td>";
                        echo "<td>" . $row["USN"] . "</td>";
                        echo "<td>" . $row["Dept"] . "</td>";
                        echo "<td>" . $row["CompanyName"] . "</td>";
                        echo "<td>" . $row["Package"] . "</td>";
                         ?>
                            <td><a href='./offerletters/<?php echo $row["offer_letter"]; ?>' target='_blank'>View Offer Letter</a></td>
<?php
                        echo "</tr>";
                        $counter++;
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
<a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout_placement.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables JavaScript -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#placedStudentsTable').DataTable();
        });
    </script>
</body>

</html>
<?php
$conn->close();
?>
