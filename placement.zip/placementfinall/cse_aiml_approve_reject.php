<?php
include "dbconfig.php";

if (isset($_POST['approve'])) {
    $usn = $_POST['usn'];
    $result = "UPDATE offer_letter SET status=1 WHERE USN='$usn'";
	$result1 = "INSERT INTO department (USN, dept, CompanyName, package, offer_letter, status) 
            SELECT USN, dept, CompanyName, package, offer_letter, status 
            FROM offer_letter 
            WHERE status = 1 AND dept = 'CSE(AIML)' AND USN = '$usn'";
    mysqli_query($conn, $result);
	mysqli_query($conn, $result1);
	header("Location:cse_aiml_approve.php");
} elseif (isset($_POST['reject'])) {
    $usn = $_POST['usn'];
    
	$result3 = "UPDATE offer_letter SET status=-1 WHERE USN='$usn'";
	
	$result5="DELETE from offer_letter where (USN='$usn'&& status=-1)";
   
	mysqli_query($conn, $result3);
	mysqli_query($conn, $result4);
	
	header("Location:cse_aiml_approve.php");
}


$conn->close();
?>
