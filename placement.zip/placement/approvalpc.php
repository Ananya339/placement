<?php
include "dbconfig.php";
$result = "SELECT USN,CompanyName,Package,offer_letter,status FROM offerform";
$iquery = mysqli_query($conn, $result);

if (mysqli_num_rows($iquery) > 0) {
    echo "<table>
            <tr>
                <th>id</th>
                <th>USN</th>
                <th>Company Name</th>
                <th>Package</th>
                <th>Offer Letter</th>
                <th>Status</th>
                <th>Action</th>
            </tr>";
    $counter = 1;

    while ($row = mysqli_fetch_assoc($iquery)) {
        echo "<tr>
                <td>" . $counter . "</td>
                <td>" . $row["USN"] . "</td>
                <td>" . $row["CompanyName"] . "</td>
                <td>" . $row["Package"] . "</td>
                <td><a href='" . $row["offer_letter"] . "'>" . $row["offer_letter"] . "</a></td>
                <td>";

        if ($row["status"] == 0) {
            echo "Pending";
        } elseif ($row["status"] == 1) {
            echo "Approved";
        } else {
            echo "Rejected";
        }

        echo "</td>
                <td>
                    <form action='approve_reject.php' method='post'>
                        <input type='hidden' name='usn' value='" . $row["USN"] . "'>
                        <button type='submit' name='approve' value='approve'>Approve</button>
                        <button type='submit' name='reject' value='reject'>Reject</button>
                    </form>
                </td>
              </tr>";

        $counter++;
    }

    echo "</table>";
}
?>
