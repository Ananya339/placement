<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome page</title>
    <style>
       html,body {
            height: 100%;
  margin: 0;
            font-family:"Times New Roman",Times,serif; 
        }
        h1 {
            font-size: 50px;
            text-align: center;
            color:	#FFDEAD;
        }
        h2 {
            font-size: 40px;
            text-align: center;
            color: 	#FFF8DC; 
        }
        .center {
           display: flex;
    justify-content: center;
    align-items: center;
    text-align: left
		
        }
        .radio-label {
            font-size: 25px; 
            display: inline-block; 
            margin-bottom: 10px;
text-align: left;			
        }
        input[type="radio"] {
            vertical-align: middle; 
            margin-right: 5px; 
        }
		* {
  box-sizing: border-box;
}
.bg-image {
  background-image: url("gsss.jpg");
  filter: blur(8px);
  -webkit-filter: blur(8px);
  
  /* Full height */
  height: 100%; 
  
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.bg-text {
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0, 0.4); /* Black w/opacity/see-through */
  color: #DAF7A6;
  font-weight: bold;
  border: 3px solid #f1f1f1;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2;
  width: 80%;
  padding: 20px;
  text-align: center;
}
    </style>
</head>
<body>
<div class="bg-image"></div>
<div class="bg-text">
    <h1>WELCOME TO PLACEMENT WEBSITE</h1>
    <h2>Login as</h2>
	
    <div class="center">
	<p>
        <label class="radio-label">
            <input type="radio" name="placement" value="Placement_Office" onclick="window.location.href = 'placement_login.php';"> Placement Office
        </label>
        <br>
        <label class="radio-label">
            <input type="radio" name="placement" value="cse_dept" onclick="window.location.href = 'cse_dept_login.php';"> CSE Department
        </label>
        <br>
        <label class="radio-label">
            <input type="radio" name="placement" value="cse_aiml_dept" onclick="window.location.href = 'cse_aiml_dept_login.php';"> CSE(AIML) Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="cse_aids_dept" onclick="window.location.href = 'cse_aids_dept_login.php';"> CSE(AI&DS) Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="ise_dept" onclick="window.location.href = 'ise_dept_login.php';">ISE Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="ece_dept" onclick="window.location.href = 'ece_dept_login.php';">ECE Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="eee_dept" onclick="window.location.href = 'eee_dept_login.php';">EEE Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="Student" onclick="window.location.href = 'student_login.php';"> Student
        </label>
		</p>
    </div>
	</div>
</body>
</html>