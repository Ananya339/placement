<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome page</title>
    <style>
        body {
           <!-- background-image: url('gsssietw.png');
            background-size: cover;-->
            background-repeat: no-repeat;
            font-family:"Times New Roman",Times,serif; 
        }
        h1 {
            font-size: 50px;
            text-align: center;
            color: black;
        }
        h2 {
            font-size: 40px;
            text-align: center;
            color: black; 
        }
        .center {
            text-align: center;
        }
        .radio-label {
            font-size: 30px; 
            display: inline-block; 
            margin-bottom: 10px; 
        }
        input[type="radio"] {
            vertical-align: middle; 
            margin-right: 5px; 
        }
    </style>
</head>
<body>
    <h1>WELCOME TO PLACEMENT WEBSITE</h1>
    <h2>Login as</h2>
    <div class="center">
        <label class="radio-label">
            <input type="radio" name="placement" value="Placement_Office" onclick="window.location.href = 'placement_login.php';"> Placement Office
        </label>
        <br>
        <label class="radio-label">
            <input type="radio" name="placement" value="cse_dept" onclick="window.location.href = 'cse_dept_login.php';"> CSE Department
        </label>
        <br>
        <label class="radio-label">
            <input type="radio" name="placement" value="cse_aiml_dept" onclick="window.location.href = 'cse_aiml_dept_login.php';"> CSE(AIML) Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="cse_aids_dept" onclick="window.location.href = 'cse_aids_dept_login.php';"> CSE(AI&DS) Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="ise_dept" onclick="window.location.href = 'ise_dept_login.php';">ISE Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="ece_dept" onclick="window.location.href = 'ece_dept_login.php';">ECE Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="eee_dept" onclick="window.location.href = 'eee_dept_login.php';">EEE Department
        </label>
		<br>
		<label class="radio-label">
            <input type="radio" name="placement" value="Student" onclick="window.location.href = 'student_login.php';"> Student
        </label>
    </div>
</body>
</html>