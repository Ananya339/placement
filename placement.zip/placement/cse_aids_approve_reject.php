<?php
include "dbconfig.php";

if (isset($_POST['approve'])) {
    $usn = $_POST['usn'];
    $result = "UPDATE aids SET status=1 WHERE USN='$usn'";
	$result1 = "UPDATE offerform SET status=1 WHERE USN='$usn'";
    mysqli_query($conn, $result);
	mysqli_query($conn, $result1);
	header("Location:cse_aids_approve.php");
} elseif (isset($_POST['reject'])) {
    $usn = $_POST['usn'];
    $result2 = "UPDATE aids SET status=-1 WHERE USN='$usn'";
	$result3 = "UPDATE offerform SET status=-1 WHERE USN='$usn'";
    mysqli_query($conn, $result2);
	mysqli_query($conn, $result3);
	header("Location:cse_aids_approve.php");
}


$conn->close();
?>
