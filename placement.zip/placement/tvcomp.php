<?php
include "dbconfig.php";

$timestamp = time();
$currentDate = gmdate('Y-m-d', $timestamp);
if(isset($_GET['date'])) {
    $date = $_GET['date'];
} else {
    $date = $currentDate;
}
$sql = "SELECT * FROM schedule_list WHERE Date='$date'";
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>TV Display</title>
    <style>
.center{
	display:block;
	margin-left:auto;
	margin-right:auto;
	width:50%
	height: 100%;
}


  .container {
    display: flex;
    justify-content: space-between;
    width: 100%; /* Full screen width */
    max-width: 1200px; /* Optionally, set a maximum width */
    border-top: 20px solid transparent; /* Top border */
  }

  .column {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    flex-basis: calc(33.33% - 20px); /* Adjust column width */
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 20px;
  }

  .column img {
    max-width: 100%;
    border-radius: 5px;
    align-self: center; /* Vertically center align the image */
  }
 </style>
</head>
<body>
<img src='header.png' width="500" height="120" class="center">
<div class="container">
<div class="column">
<img src='flowers.png'>
<center><h1 style='color: blue; text-transform: uppercase; font-size: 2em;'>Welcome</h1></center>
</div>
  <div class="column">
    <?php
    $result2 = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result2) > 0) {
        while ($row = mysqli_fetch_assoc($result2)) {
           echo "<center><h1 style='color: blue; text-transform: uppercase; font-size: 3em;'>" . strtoupper("{$row['company_name']}") . "</h1></center>";

			?>
	<?php
            echo "<center><h3 style='color: black; font-size: 2em;'>{$row['test_type']}</h3>";
            echo "<center><h2 style='color: black; font-size: 2em;'>For {$row['batch']} Batch</h2>";
			echo "<center><h4 style='color: black; font-size: 2em;'>" . date('d-m-Y', strtotime($row['date'])) . "</h4>";
			?>
</div>
  <div class="column">
        <?php
		$query = "SELECT image_path FROM companylogo where company_name=\"{$row['company_name']}\"";

        $result1 = mysqli_query($conn, $query);
        while ($data = mysqli_fetch_assoc($result1)) {
            echo "<img src='./companylogo/{$data['image_path']}' >";
        }
        ?>
		</div>
		<?php
            
			?>
			<!--<<meta http-equiv="refresh" content="10;url=tvdisplay.php"/> -->
			<?php
        }
    } else {
        echo "No companies are visitng today :)";
    }

    mysqli_close($conn);
    ?>
</div>
</body>
</html>
