<?php
include "dbconfig.php";

$timestamp = time();
$currentDate = gmdate('Y-m-d', $timestamp);
$sql = "SELECT * FROM schedule_list WHERE Date='$currentDate'";
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>TV Display</title>
    <style>
      #display-image {
            width: 100%;
            justify-content: center
            padding:5px;
            margin: 1px;
			text-align:center;
        }
		img{
    margin: 5px;
    width: 150px;
    height:100px;

}
.center{
	display:block;
	margin-left:auto;
	margin-right:auto;
	width:50%
}
 </style>
</head>
<body>
<img src='header.png' width="500" height="80" class="center">
    <?php
    $result2 = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result2) > 0) {
        while ($row = mysqli_fetch_assoc($result2)) {
           echo "<center><h1 style='color: blue; text-transform: uppercase; font-size: 3em;'>" . strtoupper("{$row['company_name']}") . "</h1></center>";

			?>
	<?php
            echo "<center><h3 style='color: black; font-size: 2.5em;'>{$row['test_type']}</h3>";
            echo "<center><h2 style='color: black; font-size: 2em;'>For {$row['batch']} Batch</h2>";
			?>
						<div id="display-image">
        <?php
		$query = "SELECT image_path FROM companylogo where company_name=\"{$row['company_name']}\"";

        $result1 = mysqli_query($conn, $query);
        while ($data = mysqli_fetch_assoc($result1)) {
            echo "<img src='./companylogo/{$data['image_path']}' >";
        }
        ?>
		</div>
		<?php
            echo "<center><h4 style='color: black; font-size: 1.5em;'>" . date('d-m-Y', strtotime($row['date'])) . "</h4>";
			?>
			<meta http-equiv="refresh" content="10;url=tvdisplay.php"/>
			<?php
        }
    } else {
        echo "No companies are visitng today :)";
    }

    mysqli_close($conn);
    ?>
</body>
</html>
