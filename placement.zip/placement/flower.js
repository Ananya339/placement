<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
      background-color: #87CEEB; /* Sky Blue */
    }

    .bouquet {
      position: relative;
      width: 200px;
      height: 300px;
    }

    .flower {
      position: absolute;
      width: 50px;
      height: 50px;
      background-color: #FFD700; /* Gold */
      border-radius: 50%;
      transform-origin: bottom center;
      animation: flowerAnimation 2s ease-in-out infinite;
    }

    @keyframes flowerAnimation {
      0%, 100% {
        transform: translateY(0) rotate(0deg);
      }
      50% {
        transform: translateY(-50px) rotate(180deg);
      }
    }
  </style>
</head>
<body>
  <div class="bouquet">
    <div class="flower" style="left: 25px;"></div>
    <div class="flower" style="left: 75px;"></div>
    <div class="flower" style="left: 125px;"></div>
  </div>

  <script>
    // Optionally, you can add more flowers dynamically using JavaScript.
    // Example:
    // const bouquet = document.querySelector('.bouquet');
    // for (let i = 0; i < 5; i++) {
    //   const flower = document.createElement('div');
    //   flower.className = 'flower';
    //   flower.style.left = `${25 * (i + 1)}px`;
    //   bouquet.appendChild(flower);
    // }
  </script>
</body>
</html>
