<!-- index.html -->
<form action="upload.php" method="post" enctype="multipart/form-data">
    Select Excel file to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload File" name="submit">
</form>
