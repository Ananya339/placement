
<?php
include "dbconfig.php";
$result = mysqli_query($conn, "SELECT * FROM offerform");

if (mysqli_num_rows($result) > 0) {
    echo "<table>
            <tr>
                <th>id</th>
                <th>USN</th>
                <th>Company Name</th>
                <th>Package</th>
                <th>Offer Letter</th>
                <th>Status</th>
            </tr>";
    $counter = 1;

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>" . $counter . "</td>
                <td>" . $row["USN"] . "</td>
                <td>" . $row["CompanyName"] . "</td>
                <td>" . $row["Package"] . "</td>
                <td><a href='" . $row["offer_letter"] . "'>" . $row["offer_letter"] . "</a></td>
                <td>";

        if ($row["status"] == 0) {
            echo "Pending";
        } elseif ($row["status"] == 1) {
            echo "Approved";
        } else {
            echo "Rejected";
        }

        echo "</td></tr>";
        $counter++;
    }

    echo "</table>";
    $conn->close();
}
?>
