<?php
$table = 'offerform o INNER JOIN student s ON o.USN = s.USN';
 
$primaryKey = 'id_no';
 
$columns = array(
    array( 'db' => 's.Name', 'dt' => 0 ),
    array( 'db' => 's.Dept',  'dt' => 1 ),
    array( 'db' => 'o.USN',   'dt' => 2 ),
    array( 'db' => 'o.CompanyName', 'dt' => 3,),
    array( 'db' => 'o.Package','dt' => 4),
	array( 'db' => 'o.offer_letter', 'dt' => 5,
        'formatter' => function( $d, $row ) {
             return '<a href="./uploads/' . $d . '">View Offer Letter</a>';
        }
    )
   
);
 
$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db'   => 'placement_web',
    'host' => 'localhost'
);
 
require( 'vendor/datatables/ssp.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);