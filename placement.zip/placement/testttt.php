<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Placements</title>
  <style>
  
	body, html {
	margin: 0;
	font-family: Arial, sans-serif;
	color: #ffffff;
	}
    .company-group {
      border: 1px solid #ddd;
      padding: 10px;
      margin-bottom: 10px;
    }

    h3 {
      text-align: center;
    }

    .student-details {
      display: inline-block;
      border: 1px solid #ddd;
      padding: 10px;
      margin-top: -700px;
      text-align: center;
    }

    img {
      width: 250px;
      height: 250px;
    }
	
	 body {
      overflow-x: hidden; /* Disabling horizontal scrolling */
	  background-color: #7b0e49;
    }
  </style>
</head>
<body>
<h1><center>Campus Placements</center></h1>
<h2><center>For batch 2025</center></h2>

<div class="company-group" id="student-container">
  <!-- Student details will be displayed here -->
</div>

<script>
var currentIndex = 0;
var rows = [{"company_name":"Amazon","student_count":"1","student_name":"bhoomika","branch":"ECE","package":"135000","photo":"6.png"},{"company_name":"Amazon","student_count":"1","student_name":"CP","branch":"ECE","package":"135000","photo":"8.png"},{"company_name":"Amazon","student_count":"1","student_name":"neha","branch":"AIML","package":"140000","photo":"5.png"},{"company_name":"Google","student_count":"1","student_name":"Ananya","branch":"CSE","package":"150000","photo":"1.png"},{"company_name":"Google","student_count":"1","student_name":"sanju","branch":"ECE","package":"145000","photo":"2.png"},{"company_name":"Microsoft","student_count":"1","student_name":"anannya","branch":"AIML","package":"130000","photo":"3.png"},{"company_name":"Microsoft","student_count":"1","student_name":"varsha","branch":"CSE","package":"125000","photo":"4.png"},{"company_name":"Visa","student_count":"1","student_name":"anusha","branch":"EEE","package":"320000","photo":"7.png"}];
var container = document.getElementById('student-container');

function displayNextRow() {
  container.innerHTML = ''; // Clear previous contents
  
  // Check if there are more rows to display
  if (currentIndex >= rows.length) {
    currentIndex = 0;
  }

  var companyName = rows[currentIndex].company_name;
  var package = rows[currentIndex].package;

  // Create a header element for the company group
  var companyHeader = document.createElement('h3');
  companyHeader.innerHTML =`<h1>Congratulations</h1> on getting placed in <b><h1>${companyName}</h1></b> With a Salary Package of <b><h1>${package} LPA</h1></b>`;
  container.appendChild(companyHeader);
companyHeader.style.width = '150%';


  // Loop through remaining rows with the same company name
  while (currentIndex < rows.length && rows[currentIndex].company_name === companyName) {
    var row = rows[currentIndex];

    // Create a student information element
    var studentInfo = document.createElement('div');
    studentInfo.className = 'student-details';

    // Check for the existence of the photo path before adding the image
    if (row["photo"]) {
      studentInfo.innerHTML = `
		 <center>
        <img src="./stu_pho/${row["photo"]}" alt="Student Photo">
		</center>
        <p>Name: ${row.student_name}</p>
        <p>Branch: ${row.branch}</p>
      `;
    } else {
      studentInfo.innerHTML = `
        <img src="default_image.png" alt="Student Photo (not available)">
        <p>Name: ${row.student_name}</p>
        <p>Branch: ${row.branch}</p>
      `;
    }
   container.appendChild(studentInfo);
   currentIndex++; // Move to the next row
  }
  
   // Call displayNextRow again after 5 seconds
   setTimeout(displayNextRow, 5000);
  
  
}

// Initially display the first row
displayNextRow();

</script>

</body>
</html>
