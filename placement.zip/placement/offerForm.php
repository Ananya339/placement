<!DOCTYPE html>
<html lang="en-us">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Offer letter</title>
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" >
        
        <style>
            .width{
                width: 600px;
            }
            @media(max-width: 600px)
            {
                .width{
                width: 350px;
            }
            }
            .error{
                color: red;
                font-size: large;
            
            }
            .success{
                color: green;
                font-size: large;
          
            }
            .error1{
                color: red;
                font-size: large;
            
            }
            .success1{
                color: green;
                font-size: large;
          
            }
            #message1{
                color: red;
            }
            #message2{
                color: red;
            }
            #message3{
                color: red;
            }
            #message4{
                color: red;
            }
            #message5{
                color: red;
            }
            img{
                margin: auto;
                border-radius: 3px;
                border: 1px solid grey;
                height: 190px;
                width: 180px;
            }
           
        </style>
          </head>
    <body>
        <div class="container-fluid pt-2 pb-5 bg-light">
            <div class="container border width rounded border-success">
                <h1 class="pt-1 text-center pb-2">Offer Letter form</h1>
                <hr class="border-bottom bg-success w-50 mx-auto">
                <hr class="border-bottom bg-success w-50 mx-auto">
                
                <form class="pt-3 w-50 mx-auto pb-3">
                    <label class="pb-2 text-center">Enter your USN:</label><span id="message1">*</span>
                    <input type="text" class="form-control" placeholder="Enter your USN" value="4GW" name="USN" id="USN" required>
                    
                    <label class="pt-1 pb-2 text-center">Enter the company name to which you are placed(in capital letters only)</label><span id="message2">*</span>
                    <input type="text" class="form-control" placeholder="Enter company name" id="CompanyName" name="CompanyName" placeholder="CompanyName"required>
                    
                    
                    <label class="pt-1 text-center">Please enter your package (LPA)</label><span id="message3">*</span>
                    <input type="number" class="form-control" placeholder="Enter your package" id="Package" placeholder="in LPA" required>
                    
                    <label class="pt-1 pb-2 text-center">Please upload your offer letter (in PDF format only and less then 2MB only)</label><span class="text-danger">*</span>
                    <input type="file" class="form-control" name="PDFFile" id="PDFFile" accept=".pdf" required>
                    
                    <br><br>
                    <button type="button" class="form-control btn btn-outline-primary" id="submit" disabled="true" onclick="getValues()">Submit</button>
                    <br><br>
                    <span class="error"></span><span class="success"></span>
                   
                </form>
              

                <form action="show-data-1.php" action="" method="post" class="pt-3 w-50 mx-auto pb-3">
                    <input type="submit" class="form-control btn btn-outline-primary" value="Show data">
                </form>
                
            </div>
        </div>
     
        
        <script src="script.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!-- JavaScript Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" ></script>
        <script>
        
               
<!--$('#password1, #password2').on('keyup', function () {
                if($('#password1').val() == $('#password2').val() && $('#password1').val().length != 0) 
                {
                              $('#message5').html('Matched').css('color', 'green');
                               $("#submit").prop('disabled',false);
                } 
                 else 
                 {
                              $('#message5').html('Password Missmatch').css('color', 'red');
                              $("#submit").prop('disabled',true);
                 }
                }
                );
        
  		        $('#fname').on('keyup',function() {
  		            if($('#fname').val().length != 0)
  		            {
  		                  $('#message1').html('*').css('color','green');
  		                  $("#submit").prop('disabled',false);
  		                
  		            }
  		            else
  		            {
                        $('#message1').html('*').css('color','red');
                        $("#submit").prop('disabled',true);
  		            }
  		        }
  		        );
  		        $('#lname').on('keyup',function() {
  		            if($('#lname').val().length != 0)
  		            {
  		                  $('#message2').html('*').css('color','green');
  		                  $("#submit").prop('disabled',false);
  		                
  		            }
  		            else
  		            {
                          $('#message2').html('*').css('color','red');
                          $("#submit").prop('disabled',true);
  		            }
  		        }
  		        );
  		       var validateEmail = function(elementValue) {
                    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
                    return emailPattern.test(elementValue);
                }



                $('#email').keyup(function() {
                
                    var value = $(this).val();
                    var valid = validateEmail(value);
                
                    if (!valid) {
                
                
                        $('#message3').html(' Invalid email').css('color', 'red');
                        $("#submit").prop('disabled',true);
                
                    } else {
                
                
                        $('#message3').html(' *').css('color', 'green');
                        $("#submit").prop('disabled',false);
                
                    }
                });
  		        
  		    
  		        $('#mobile').on('keyup',function() {
  	        	    if($('#mobile').val().length == 10 )
  	        	    {
  	        	        $('#message4').html(' *').css('color','green');
  	        	     
  	        	    }
  	        	    else
  	        	        $('#message4').html(' Enter 10 digits').css('color','red');
  	        	      
  	        	}
  	        	);-->
  	        	
            
        </script>
    </body>
</html>