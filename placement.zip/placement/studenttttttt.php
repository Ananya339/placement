<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Placements</title>
  <style>
    /* Your CSS styles */
	body, html {
		margin: 0;
		font-family: Arial, sans-serif;
		color: #ffffff;
	}
    .company-group {
      border: 1px solid #ddd;
      padding: 10px;
      margin-bottom: 10px;
    }

    h3 {
      text-align: center;
    }

    .student-details {
      display: inline-block;
      border: 1px solid #ddd;
      padding: 10px;
      margin-top: -700px;
      text-align: center;
    }

    img {
      width: 250px;
      height: 250px;
    }
	
	 body {
      overflow-x: hidden; /* Disabling horizontal scrolling */
	  background-color: #7b0e49;
    }
  </style>
</head>
<body>
<h1><center>Campus Placements</center></h1>
<h2><center>For batch 2025</center></h2>

<div class="company-group" id="student-container">
  <!-- Student details will be displayed here -->
</div>

<?php
$server = "localhost";
$user = "root";
$password = "";
$dbname = "placement_web";

// Create connection
$conn = new mysqli($server, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Improved SQL query to group students by company with aggregation
$sql = "SELECT o.CompanyName, COUNT(*) AS student_count, o.Package, s.Name, s.USN, s.Dept, s.student_photo
FROM offerform o
INNER JOIN student s ON o.USN = s.USN
WHERE o.status = 1
GROUP BY o.CompanyName, s.Name, s.Dept, o.Package
ORDER BY o.Package DESC, o.CompanyName";



// Execute the query
$result = $conn->query($sql);

// Check if the query was successful
if ($result->num_rows > 0) {
    // Fetch all rows as an associative array
    $rows = $result->fetch_all(MYSQLI_ASSOC);
} else {
    echo "No results found";
}

// Close connection
$conn->close();
?>

<script>
var currentIndex = 0;
var rows = <?php echo json_encode($rows); ?>;
var container = document.getElementById('student-container');

function displayNextRow() {
  container.innerHTML = ''; // Clear previous contents
  
  // Check if there are more rows to display
  if (currentIndex >= rows.length) {
    currentIndex = 0;
  }

  var CompanyName = rows[currentIndex].CompanyName;
  var Package = rows[currentIndex].Package;

  // Create a header element for the company group
  var companyHeader = document.createElement('h3');
  companyHeader.innerHTML =`<h1>Congratulations</h1> on getting placed in <b><h1>${CompanyName}</h1></b> With a Salary Package of <b><h1>${Package} LPA</h1></b>`;
  container.appendChild(companyHeader);
  companyHeader.style.width = '150%';


  // Loop through remaining rows with the same company name
  while (currentIndex < rows.length && rows[currentIndex].CompanyName === CompanyName) {
    var row = rows[currentIndex];

    // Create a student information element
	
    var studentInfo = document.createElement('div');
    studentInfo.className = 'student-details';

    // Check for the existence of the photo path before adding the image
    if (row["student_photo"]) {
      studentInfo.innerHTML = `
		 <center>
        <img src="./student_photo/${row["student_photo"]}" alt="Student Photo">
		</center>
        <p>Name: ${row.Name}</p>
        <p>Branch: ${row.Dept}</p>
      `;
    } else {
      studentInfo.innerHTML = `
        <img src="default_image.png" alt="Student Photo (not available)">
        <p>Name: ${row.Name}</p>
        <p>Branch: ${row.Dept}</p></marquee>
      `;
    }
    container.appendChild(studentInfo);
    currentIndex++; // Move to the next row
  }
  
   // Call displayNextRow again after 5 seconds
   setTimeout(displayNextRow, 5000);
}

// Initially display the first row
displayNextRow();
</script>

</body>
</html>
