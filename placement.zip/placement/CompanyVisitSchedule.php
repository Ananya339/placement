<?php
include "dbconfig.php";

if(isset($_POST['submit'])){  // Use $_POST instead of $_post
    $Company_Name = $_POST['Company_Name'];
    $Test_Type = $_POST['Test_Type'];
    $Branch = $_POST['Branch'];
    $Year = $_POST['Year'];
    $Date = $_POST['Date'];
	$filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $folder = "./companylogo/" . $filename;

    $sql = "INSERT INTO compvisitform (Company_Name, Test_Type, Branch, Year, Date) VALUES ('$Company_Name', '$Test_Type', '$Branch', '$Year', '$Date')";
    $sql3= "INSERT INTO companylogo (company_name, image_path) VALUES ('$Company_Name','$filename')";	
if(mysqli_query($conn, $sql)&& mysqli_query($conn, $sql3)) {
	echo "";
    } else {
        echo "Error: " . mysqli_error($conn);  // Display the actual MySQL error for debugging
    }
}

echo "<head>
    <title>Student Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #0000FF;
            color: white;
        }

        h1 {
            text-align: center;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #00FFFF;
            color: #000000;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px; /* Add margin for spacing */
        }
    </style>
</head>";
echo"<body>

    <div>
        <h1>Company Visit Schedule</h1>";
		$timestamp = time();
$currentDate = gmdate('Y-m-d', $timestamp);

$sql="select*from compvisitform WHERE Date>='$currentDate'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
        echo "<table>
            <tr>
			<th>id</th>
                <th>Company Name</th>
                <th>Test Type</th>
                <th>Branch</th>
                <th>Batch</th>
                <th>Date</th>
				
            </tr>";
			$counter = 1;
         	while($row=mysqli_fetch_assoc($result))
	{
		echo"<tr>
		<td>" . $counter . "</td>
		<td>".$row["Company_Name"]."</td>
		<td>".$row["Test_Type"]."</td>
		<td>".$row["Branch"]."</td>
		<td>".$row["Year"]."</td>
		<td>" . date('d-m-Y', strtotime($row["Date"])) . "</td>";
		?>
		<!--<td><button type="button" onclick="window.location.href = 'delete.php' value="delete" name="delete">Delete</button>
</td>
<td align='center'>
<a href="delete.php?id=<?php echo $row["Company_Name"]; ?>">Delete</a>
</td>-->

		</tr>
		<?php
	}
	echo"</table>";
}
else
{
	echo"0 results";
}
mysqli_close($conn);

        echo "</table>";
		
    echo"
	<br>
	<p align='right'>
    <a href='offerForm.php'>
     
  <input type='submit' value='IF PLACED CLICK ON THIS' name='submit' style = 'font-size:15px' align='center'>></a>
</p>


</body>
</html>";
?>