<?php
include "dbconfig.php";

if (isset($_POST['approve'])) {
    $usn = $_POST['usn'];
    $result = "UPDATE cseaiml SET status=1 WHERE USN='$usn'";
	$result1 = "UPDATE offerform SET status=1 WHERE USN='$usn'";
    mysqli_query($conn, $result);
	mysqli_query($conn, $result1);
	header("Location:cse_aiml_approve.php");
} elseif (isset($_POST['reject'])) {
    $usn = $_POST['usn'];
    $result2 = "UPDATE cseaiml SET status=-1 WHERE USN='$usn'";
	$result3 = "UPDATE offerform SET status=-1 WHERE USN='$usn'";
	$result4="DELETE from cseaiml  WHERE (USN='$usn'&& status=-1)";
	$result5="DELETE from offerform where (USN='$usn'&& status=-1)";
    mysqli_query($conn, $result2);
	mysqli_query($conn, $result3);
	mysqli_query($conn, $result4);
	mysqli_query($conn, $result5);
	header("Location:cse_aiml_approve.php");
}


$conn->close();
?>
