<?php
include "dbconfig.php";

if (isset($_POST['submit'])) {
    $USN = $_POST['USN'];
	$dept=$_POST['dept'];
    $CompanyName = $_POST['CompanyName'];
    $Package = $_POST['Package'];

    if (isset($_FILES['pdf_file'])) {
        $file_name = $_FILES['pdf_file']['name'];
        $file_tmp = $_FILES['pdf_file']['tmp_name'];

        move_uploaded_file($file_tmp, "./uploads/" . $file_name);	
      
		$insertquery2=" SELECT USN FROM offerform WHERE USN='$USN'";
		$iquery2=mysqli_query($conn,$insertquery2);
      
        

if (mysqli_num_rows($iquery2) > 0) {
    $message3 = "This USN already exists!! Sorry you cannot upload details with this USN";
    ?>
    <script>
        window.onload = function() {
            alert("<?php echo $message3; ?>");
            // Redirect to a specific page after displaying the alert
            window.location.href = "student1.php";
        };
    </script>
    <?php
}
else{
else {
    if (isset($_FILES['pdf_file']) && $_FILES['pdf_file']['error'] == 0) {
        $insertquery = "INSERT INTO offerform (USN, dept, CompanyName, Package, offer_letter) 
                        VALUES ('$USN', '$dept','$CompanyName', '$Package', '$file_name')";
        $iquery = mysqli_query($conn, $insertquery);

        // Check if the query was successful before proceeding
        if ($iquery) {
            $insertqueryCombined = "INSERT INTO " . strtolower($dept) . " (USN, dept, CompanyName, Package, offer_letter, status) 
                                SELECT USN, dept, CompanyName, Package, offer_letter, status FROM offerform WHERE dept='$dept'";
            $iqueryCombined = mysqli_query($conn, $insertqueryCombined);

            if ($iqueryCombined) {
                echo "";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}

    $message1 = "The details have been successfully uploaded!! Please wait for approval!!";
    ?>
    <script>
        window.onload = function() {
            alert("<?php echo $message1; ?>");
            // Redirect to a specific page after displaying the alert
            window.location.href = "student1.php";
        };
    </script>
    <?php
} else {
	echo "Error: " . mysqli_error($conn);
    $message2 = "File not selected. Please choose a file and try again!";
    ?>
   <script>
        window.onload = function() {
            alert("<?php// echo $message2; ?>");
            // Redirect to a specific page after displaying the alert
            window.location.href = "offer_letter.php";
        };
    </script>
    <?php
}
}
    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>offer_letter</title>
</head>
<body>
    <!-- Your HTML content -->
</body>
</html>

<?php

$conn->close();
?>
