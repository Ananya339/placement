<?php
include "dbconfig.php";

if (isset($_POST['approve'])) {
    $usn = $_POST['usn'];
    $result = "UPDATE offerform SET status=1 WHERE USN='$usn'";
    mysqli_query($conn, $result);
	header("Location:cse_approve.php");
} elseif (isset($_POST['reject'])) {
    $usn = $_POST['usn'];
    $result1 = "UPDATE offerform SET status=-1 WHERE USN='$usn'";
    mysqli_query($conn, $result1);
	header("Location:cse_approve.php");
}

$result2 = "SELECT * FROM offerform";  
$iquery = mysqli_query($conn, $result2);

if (mysqli_num_rows($iquery) > 0) {
    echo "<table>
            <tr>
                <th>id</th>
                <th>USN</th>
                <th>Company Name</th>
                <th>Package</th>
                <th>Offer Letter</th>
                <th>Status</th>
            </tr>";
    $counter = 1;

    while ($row = mysqli_fetch_assoc($iquery)) {
        // Determine the status
        if ($row["status"] == 0) {
            $status = "Pending";
        } elseif ($row["status"] == 1) {
            $status = "Approved";
        } else {
            $status = "Rejected";
        }

        echo "<tr>
                <td>" . $counter . "</td>
                <td>" . $row["USN"] . "</td>
                <td>" . $row["CompanyName"] . "</td>
                <td>" . $row["Package"] . "</td>
                <td><a href='" . $row["offer_letter"] . "'>" . $row["offer_letter"] . "</a></td>
                <td>" . $status . "</td>
              </tr>";

        $counter++;
    }

    echo "</table>";
}

$conn->close();
?>
