<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Placements</title>
  <style>
    /* Your CSS styles */
	body, html {
		margin: 0;
		font-family: 'Helvetica'
		color: #000000;
	}
    .company-group {
      border: 1px solid #ddd;
      padding: 10px;
      margin-bottom: 10px;
    }

    h3 {
      text-align: center;
    }

    .student-details {
   display: inline-block;
   border: 1px solid #ddd;
   padding: 10px;
   /* margin-top: -700px; Remove or adjust this line */
   text-align: center;
}
.center{
	display:block;
	margin-left:auto;
	margin-right:auto;
	width:50%
}
	
	 body {
      overflow-x: hidden; /* Disabling horizontal scrolling */
	  overflow-y: hidden;
	  background-color: #ff9900
    }
	.bolded{
		font-weight:bold;
	}
  </style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/@tsparticles/confetti@3.0.3/tsparticles.confetti.bundle.min.js"></script>
<img src='header.png' width="500" height="80" class="center">

<h1><center>Campus Placements</center></h1>
<h2><center>For batch 2025</center></h2>

<div class="company-group" id="student-container">
  <!-- Student details will be displayed here -->
</div>

<?php
$server = "localhost";
$user = "root";
$password = "";
$dbname = "placement_web";

// Create connection
$conn = new mysqli($server, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Improved SQL query to group students by company with aggregation
$sql = "SELECT o.CompanyName, COUNT(*) AS student_count, o.Package,s.Name, s.USN, s.Dept, s.student_photo
FROM offerform o
INNER JOIN student s ON o.USN = s.USN
WHERE o.status = 1
GROUP BY o.CompanyName, s.Name, s.Dept, o.Package
ORDER BY o.Package DESC, o.CompanyName";



// Execute the query
$result = $conn->query($sql);

// Check if the query was successful
if ($result->num_rows > 0) {
    // Fetch all rows as an associative array
    $rows = $result->fetch_all(MYSQLI_ASSOC);
} else {
    echo "No results found";
}

// Close connection
$conn->close();
?>

<script>

const end = Date.now() + 15 * 1000;

// go Buckeyes!
const colors = ["#bb0000", "#ffffff"];

(function frame() {
  confetti({
    particleCount: 2,
    angle: 60,
    spread: 55,
    origin: { x: 0 },
    colors: colors,
  });

  confetti({
    particleCount: 2,
    angle: 120,
    spread: 55,
    origin: { x: 1 },
    colors: colors,
  });

  if (Date.now() < end) {
    requestAnimationFrame(frame);
  }
})();

var currentIndex = 0;
var rows = <?php echo json_encode($rows); ?>;
var container = document.getElementById('student-container');


function displayNextRow() {
  container.innerHTML = ''; // Clear previous contents

  // Check if there are more rows to display
  if (currentIndex >= rows.length) {
    currentIndex = 0;
  }

  var CompanyName = rows[currentIndex].CompanyName;
  var Package = rows[currentIndex].Package;

  // Create a header element for the company group
  var companyHeader = document.createElement('h1');
  companyHeader.style.textAlign = "center";
  companyHeader.innerHTML = `<div style="white-space: nowrap;">Congratulations on getting placed in ${CompanyName.toUpperCase()} with a Salary Package of <b>${Package} LPA</b></div>`;

  container.appendChild(companyHeader);

  // Create a marquee element for scrolling
  var marqueeElement = document.createElement('marquee');
  marqueeElement.setAttribute('direction', 'left');
  marqueeElement.setAttribute('behavior', 'scroll');

  // Loop through remaining rows with the same company name
  while (currentIndex < rows.length && rows[currentIndex].CompanyName === CompanyName) {
    var row = rows[currentIndex];

    // Create a student information element
    var studentInfo = document.createElement('div');
    studentInfo.className = 'student-details';

    // Check for the existence of the photo path before adding the image
    if (row["student_photo"]) {
      studentInfo.innerHTML = `
        <center>
          <img src="./student_photo/${row["student_photo"]}" alt="Student Photo" width="200" height="200">
        </center>
        <p>Name: ${row.Name}</p>
        <p>Branch: ${row.Dept}</p>`;
    } else {
      studentInfo.innerHTML = `
        <center>
          <img src="default_image.png" alt="Student Photo (not available)" width="150" height="150">
        </center>
        <p>Name: ${row.Name}</p>
        <p>Branch: ${row.Dept}</p>`;
    }

    marqueeElement.appendChild(studentInfo);
    currentIndex++; // Move to the next row
  }

  container.appendChild(marqueeElement);

  // Call displayNextRow again after 5 seconds
 setTimeout(displayNextRow, 18000);
}

// Initially display the first row
displayNextRow();
</script>
<?php
include "dbconfig.php";

$timestamp = time();
$currentDate = gmdate('Y-m-d', $timestamp);
$sql = "SELECT * FROM schedule_list WHERE Date='$currentDate'";
?>
<?php
    $result2 = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result2) > 0) {
        while ($row = mysqli_fetch_assoc($result2)) {
			?>
        <?php
		$query = "SELECT image_path FROM companylogo where company_name=\"{$row['company_name']}\"";

        $result1 = mysqli_query($conn, $query);
        while ($data = mysqli_fetch_assoc($result1)) {
        echo"";
        }
        ?>
			<meta http-equiv="refresh" content="15;url=tvcomp.php"/>
			<?php
        }
    } else {
        echo "";
    }

    mysqli_close($conn);
    ?>


</body>
</html>
