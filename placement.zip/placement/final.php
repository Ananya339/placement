<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Placements</title>
  <style>
    /* Your CSS styles */
	body, html {
		margin: 0;
		font-family: Arial, sans-serif;
		color: #ffffff;
	}
    .company-group {
      border: 1px solid #ddd;
      padding: 10px;
      margin-bottom: 10px;
    }

    h3 {
      text-align: center;
    }

    .student-details {
   display: inline-block;
   border: 1px solid #ddd;
   padding: 10px;
   /* margin-top: -700px; Remove or adjust this line */
   text-align: center;
}


    img {
      width: 250px;
      height: 250px;
    }
	
	 body {
      overflow-x: hidden; /* Disabling horizontal scrolling */
	  background-color: #000066;
    }
  </style>
</head>
<body>
<h1><center>Campus Placements</center></h1>
<h2><center>For batch 2025</center></h2>

<div class="company-group" id="student-container">
  <!-- Student details will be displayed here -->
</div>

<?php
$server = "localhost";
$user = "root";
$password = "";
$dbname = "placement_web";

// Create connection
$conn = new mysqli($server, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Improved SQL query to group students by company with aggregation
$sql = "SELECT o.CompanyName, COUNT(*) AS student_count, o.Package,s.Name, s.USN, s.Dept, s.student_photo
FROM offerform o
INNER JOIN student s ON o.USN = s.USN
WHERE o.status = 1
GROUP BY o.CompanyName, s.Name, s.Dept, o.Package
ORDER BY o.Package DESC, o.CompanyName";

// Execute the query
$result = $conn->query($sql);

// Check if the query was successful
if ($result->num_rows > 0) {
    // Fetch all rows as an associative array
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    // Debugging output to check query results
    echo "<pre>";
    print_r($rows);
    echo "</pre>";
} else {
    echo "No results found";
}

// Close connection
$conn->close();
?>

<script>
var container = document.getElementById('student-container');
var currentIndex = 0;
var rows = <?php echo json_encode($rows); ?>;

function displayNextRow() {
  container.innerHTML = ''; // Clear previous contents

  // Check if there are more rows to display
  if (currentIndex >= rows.length) {
    currentIndex = 0;
  }

  var CompanyName = rows[currentIndex].CompanyName;
  var Package = rows[currentIndex].Package;

  // Create a header element for the company group
  var companyHeader = document.createElement('h3');
  companyHeader.innerHTML = `Congratulations on getting placed in <b>${CompanyName}</b> With a Salary Package of <b>${Package} LPA</b>`;
  container.appendChild(companyHeader);

  // Create a div element for student details
  var studentDetailsDiv = document.createElement('div');
  studentDetailsDiv.className = 'student-details';

  // Loop through remaining rows with the same company name
  while (currentIndex < rows.length && rows[currentIndex].CompanyName === CompanyName) {
    var row = rows[currentIndex];

    // Create a student information element
    var studentInfo = document.createElement('div');
    studentInfo.className = 'student-info';

    // Check for the existence of the photo path before adding the image
    if (row["student_photo"]) {
      studentInfo.innerHTML = `
        <center>
          <img src="./student_photo/${row["student_photo"]}" alt="Student Photo">
        </center>
        <p>Name: ${row.Name}</p>
        <p>Branch: ${row.Dept}</p>`;
    } else {
      studentInfo.innerHTML = `
        <center>
          <img src="default_image.png" alt="Student Photo (not available)">
        </center>
        <p>Name: ${row.Name}</p>
        <p>Branch: ${row.Dept}</p>`;
    }

    studentDetailsDiv.appendChild(studentInfo);
    currentIndex++; // Move to the next row
  }

  // Append both div elements to the main container
  container.appendChild(companyHeader);
  container.appendChild(studentDetailsDiv);

  // Call displayNextRow again after 5 seconds
  setTimeout(displayNextRow, 18000);
}

// Initially display the first row
displayNextRow();
</script>

<?php
include "dbconfig.php";

$timestamp = time();
$currentDate = gmdate('Y-m-d', $timestamp);
$sql = "SELECT * FROM schedule_list WHERE Date='$currentDate'";

$result2 = mysqli_query($conn, $sql);

if (mysqli_num_rows($result2) > 0) {
    while ($row = mysqli_fetch_assoc($result2)) {
?>
    <?php
    $query = "SELECT image_path FROM companylogo where company_name=\"{$row['company_name']}\"";

    $result1 = mysqli_query($conn, $query);
    while ($data = mysqli_fetch_assoc($result1)) {
        echo"";
    }
    ?>
    <meta http-equiv="refresh" content="100;url=tvcomp.php"/>
<?php
    }
} else {
    echo "No companies are visiting today :)";
}

mysqli_close($conn);
?>

</body>
</html>
