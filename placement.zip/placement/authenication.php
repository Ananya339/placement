<?php      
    include('dbconfig.php');  
	session_start();
    $username = $_POST['user'];  
    $password = $_POST['pass'];  
      
        //to prevent from mysqli injection  
        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $username = mysqli_real_escape_string($conn, $username);  
        $password = mysqli_real_escape_string($conn, $password);  
      
        $sql = "select *from placement_login where username = '$username' and password = '$password'";  
        $result = mysqli_query($conn, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){ 
		$_SESSION["username"]=$username;
echo"
<script>		
window.alert('Login Successfull');
window.location.href = 'placement1';</script>";

		
        }  
        else{  
             echo" <script>		
window.alert('Invalid Username or Password!!! Please enter valid details');
window.location.href = 'placement login';</script>";
        }     
?>  