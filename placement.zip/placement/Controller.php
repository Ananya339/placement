<?php
session_start();
error_reporting(E_ALL & ~ E_NOTICE);
class Controller
{
    function __construct() 
    {
        $this->processUSNVerification();
    }
    function processUSNVerification()
    {
        switch ($_POST["action"]) 
        {
                        
            case "save_into_db":

                $USN = $_POST['USN'];
                $CompanyName = $_POST['CompanyName'];
                $Package = $_POST['Package'];
				$file_name=$_FILES['pdf_file']['name'];
				$file_tmp=$_FILES['pdf_file']['tmp_name'];
				move_uploaded_file($file_tmp,"./pdf/".$file_name);
                $db = mysqli_connect('localhost', 'root', '', 'placement_web');
                $query1 = "SELECT CompanyName FROM test WHERE USN='$USN'";
                $result1 = mysqli_query($db, $query1);
                $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);
                if($row){
                        echo json_encode(array( "type" =>"error", "message" => "USN already exist."));
                        exit();
                }
                else{
                        $query = "INSERT INTO testdemo (USN,CompanyName,Package,offer_letter) VALUES ('$USN','$CompanyName','$Package','$file_name')";
                        $result = mysqli_query($db, $query);
                        if ($result == FALSE) 
                        {
                                die(mysqli_error());
                                echo json_encode(array( "type" =>"error", "message" => "Error."));
                                exit();
                        }
                        else
                               
                             echo json_encode(array( "type" =>"success", "message" => "Successfully inserted."));
                    }
                
                break;
    }
}
$controller = new Controller();
?>