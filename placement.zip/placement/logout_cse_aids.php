<?php
session_start();
session_unset();
session_destroy();
header("Location:cse_aids_dept_login.php");
exit();
?>