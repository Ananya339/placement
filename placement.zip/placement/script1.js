function getValues(){
    var USN = $('#USN').val();
    var CompanyName = $('#CompanyName').val();
    var Package = $('#Package').val();

    if(USN.length !==0 && CompanyName.length !==0 && Package.length !== 0){
        var input = {
            "USN" : USN,
            "CompanyName" : CompanyName,
            "Package" : Package,
			getFilePath();
            "action" : "save_into_db"
        };
		function getFilePath(){
			$('input[type=file]').change(function(){
				var offer_letter=$('#offer_letter').val();
			});
		}
        $.ajax({
            url : 'controller.php',
            type : 'POST',
            dataType : "json",
            data : input,
            success : function(response)
            {
                $('.success').html(response.message).show();
                $('.error').hide();
            },
            error : function(response)
            {
                 $('.error').html("Error").show();
                 $('.success').hide();
            }
        });
    }
    else
    {
           
            $('.error').html("One or more than one field empty.").show();
            $('.success').hide();
    }
}