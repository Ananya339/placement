<!DOCTYPE html>
<html lang="en-us">
<head>
    <!-- ... your existing head content ... -->
    <script>
        function updateDepartment() {
            // Get the USN input value
            var usnInput = document.getElementById('USN').value;

            // Define patterns to match USN format for different departments
            var csePattern = /^4GW[A-Z]{2}\d{3}$/;
            var aimlPattern = /^4GWAIML[A-Z]{2}\d{3}$/;
            var aidsPattern = /^4GWAI&DS[A-Z]{2}\d{3}$/;
            // Add more patterns for other departments as needed

            // Determine the department based on the pattern
            var department;
            if (csePattern.test(usnInput)) {
                department = 'CSE';
            } else if (aimlPattern.test(usnInput)) {
                department = 'CSE(AIML)';
            } else if (aidsPattern.test(usnInput)) {
                department = 'CSE(AI&DS)';
            } else {
                // Set a default value or handle other cases
                department = 'Unknown Department';
            }

            // Update the department dropdown
            document.getElementById('dept').value = department;
        }
    </script>
</head>
<body>
    <!-- ... your existing body content ... -->
    <center><h1>Offer Letter Form</h1></center>
    <form action="offer1.php" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
        <table>
            <!-- ... your existing table rows ... -->
        </table>
        <div>
            <input type="submit" value="Submit" name="submit">
            <button type="button" onclick="editForm()">Edit</button>
            <input type="reset" value="Clear">
        </div>
    </form>

    <!-- ... your existing styles ... -->

    <script>
        function validateForm() {
            // Add JavaScript validation logic here
            // Return false to prevent form submission if validation fails
            return true;
        }

        function editForm() {
            // Add logic to reset or modify the form for editing
        }

        // Call the updateDepartment function when the page loads or when the USN input changes
        window.onload = function() {
            updateDepartment();
        };

        // Add an event listener for the input change event
        document.getElementById('USN').addEventListener('input', updateDepartment);
    </script>
</body>
</html>
