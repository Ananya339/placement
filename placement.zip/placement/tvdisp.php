<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Congratulations on Placement</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h1>Congratulations</h1>
<h2>For getting placed in *Company name*</h2>
<h3>With a Salary Package of *package*</h3>

<table>
    <thead>
        <tr>
            <th>Sl. No</th>
            <th>Name</th>
            <th>Branch</th>
           
        </tr>
    </thead>
    <tbody id="placementData"></tbody>
</table>

<script>
    // Dummy data (replace with data fetched from your database)
    var placements = [
        { slNo: 1, name: 'John Doe', branch: 'Computer Science', companyName: 'TechCorp', salary: '$80,000' },
        { slNo: 2, name: 'Jane Smith', branch: 'Electrical Engineering', companyName: 'InnoTech', salary: '$75,000' },
        // Add more data as needed
    ];

    // Function to display placement data in the table
    function displayPlacements() {
        var tableBody = document.getElementById('placementData');
        tableBody.innerHTML = '';

        placements.forEach(function (placement) {
            var row = document.createElement('tr');
            row.innerHTML = `
                <td>${placement.slNo}</td>
                <td>${placement.name}</td>
                <td>${placement.branch}</td>
                
            `;
            tableBody.appendChild(row);
        });
    }

    // Call the function to display placements when the page loads
    displayPlacements();
</script>

</body>
</html>
