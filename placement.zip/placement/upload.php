<?php
require 'vendor/autoload.php'; // Include PhpSpreadsheet library

// Database connection parameters
$dbHost = 'localhost';
$dbName = 'placement_web';
$dbUser = 'root';
$dbPassword = '';

// Connect to the database
$conn = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPassword);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if (isset($_POST['submit'])) {
    $uploadedFile = $_FILES['file']['tmp_name'];

    // Load Excel file
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($uploadedFile);
    $sheet = $spreadsheet->getActiveSheet();

    // Process each row and insert into the database
    foreach ($sheet->getRowIterator() as $row) {
        // Initialize an array to store cell values
        $rowData = [];

        // Iterate over cells in the row
        foreach ($row->getCellIterator() as $cell) {
            $rowData[] = $cell->getValue();
        }

        // Assuming your Excel columns are in a specific order
        $column1 = $rowData[0];
        $column2 = $rowData[1];
        $column3 = $rowData[2];
        $column4 = $rowData[3];
        $column5 = $rowData[4];

        // Assuming date_of_birth and phone columns are in indices 3 and 4
       

        // Format date if needed (adjust the format based on your Excel data)
        

        // Insert data into the database
        $stmt = $conn->prepare("INSERT INTO student(Name, USN, Dept, Email, Year_of_Passing) VALUES (:column1, :column2, :column3, :column4, :column5)");
        $stmt->bindParam(':column1', $column1);
        $stmt->bindParam(':column2', $column2);
        $stmt->bindParam(':column3', $column3);
        $stmt->bindParam(':column4', $column4);
        $stmt->bindParam(':column5', $column5);
        // ... bind more parameters as needed

        try {
            $stmt->execute();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    echo "Data inserted successfully.";
}
?>
