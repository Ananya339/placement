<?php
$allowedExtensions = array("pdf", "doc", "docx");
$uploadDir = "uploads/";

if(isset($_FILES["offerLetter"]) && $_FILES["offerLetter"]["error"] == 0){
    $fileInfo = pathinfo($_FILES["offerLetter"]["name"]);
    $fileExtension = strtolower($fileInfo["extension"]);

    if(in_array($fileExtension, $allowedExtensions)){
        $newFileName = uniqid() . "." . $fileExtension;
        $destination = $uploadDir . $newFileName;

        if(move_uploaded_file($_FILES["offerLetter"]["tmp_name"], $destination)){
            $response = array("message" => "Offer letter uploaded successfully.");
        } else {
            $response = array("message" => "Error uploading offer letter.");
        }
    } else {
        $response = array("message" => "Invalid file format. Please upload a PDF, DOC, or DOCX file.");
    }
} else {
    $response = array("message" => "Error uploading offer letter.");
}

header('Content-Type: application/json');
echo json_encode($response);
?>