var calendar;
var Calendar = FullCalendar.Calendar;
var events = [];

$(function() {

    if (!!scheds) {
        Object.keys(scheds).map(k => {
            var row = scheds[k]
            events.push({ id: row.id, company_name: row.company_name, dept: row.dept, batch: row.batch, test_type: row.test_type, date: row.date});
        });
    }
    console.log('Scheds Object:', scheds);

    var date = new Date()
    var d = date.getDate(),
        m = date.getMonth(),
        y = date.getFullYear(),

    calendar = new Calendar(document.getElementById('calendar'), {
        headerToolbar: {
            left: 'prev,next today',
            right: 'dayGridMonth,dayGridWeek,list',
            center: 'title',
        },
        selectable: true,
        themeSystem: 'bootstrap',
        events: events,
        eventClick: function(info) {
            var details = $('#event-details-modal');
            var id = info.event.id;

            if (!!scheds[id]) {
				 console.log('Event Type Other:', scheds[id].event_type_other);
                details.find('#company_name').text(scheds[id].company_name);
                details.find('#dept').text(scheds[id].dept);
                details.find('#batch').text(scheds[id].batch);
                details.find('#test_type').text(scheds[id].test_type);
				
				details.find('#date').text(scheds[id].date);
                details.find('#edit,#delete').attr('data-id', id);
                details.modal('show');
            } else {
                alert("Event is undefined");
            }
        },
        eventDidMount: function(info) {
           
        },
        editable: true
    });

    calendar.render();

    // Form reset listener
    $('#schedule-form').on('reset', function() {
        $(this).find('input:hidden').val('');
        $(this).find('input:visible').first().focus();
    });

    // Edit Button
    $('#edit').click(function() {
        var id = $(this).attr('data-id');

        if (!!scheds[id]) {
            var form = $('#schedule-form');
 console.log('Event Type Other:', scheds[id].event_type_other);
            console.log(String(scheds[id].date).replace(" ", "\\t"));
            form.find('[name="id"]').val(id);
            form.find('[name="company_name"]').val(scheds[id].company_name);
            form.find('[name="dept"]').val(scheds[id].dept);
			form.find('[name="batch"]').val(scheds[id].batch);
			form.find('[name="test_type"]').val(scheds[id].test_type);
			
            form.find('[name="date"]').val(String(scheds[id].date).replace(" ", "T"));
            $('#event-details-modal').modal('show');
            form.find('[name="title"]').focus();
        } else {
            alert("Event is undefined");
        }
    });

    // Delete Button / Deleting an Event
    $('#delete').click(function() {
        var id = $(this).attr('data-id');

        if (!!scheds[id]) {
            var _conf = confirm("Are you sure to delete this scheduled event?");
            if (_conf === true) {
                location.href = "./delete_schedule.php?id=" + id;
            }
        } else {
            alert("Event is undefined");
        }
    });
});