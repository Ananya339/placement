<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "placement_web";

$conn = new mysqli($hostname, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT o.CompanyName, COUNT(*) AS student_count, o.Package, s.Name, s.USN, s.Dept, s.student_photo
FROM offerform o
INNER JOIN student s ON o.USN = s.USN
WHERE o.status = 1
GROUP BY o.CompanyName, s.Name, s.Dept, o.Package
ORDER BY o.Package , o.CompanyName";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $rowCounter = 0;

    // Fetch data
    while ($row = $result->fetch_assoc()) {
        // Display marquee for each row
       echo '<marquee behavior="scroll" direction="left" style="display: ' . ($rowCounter == 0 ? 'block' : 'none') . ';">' . $row['CompanyName'] . ', ' . $row['Package'] . '</marquee>';
        $rowCounter++;
    }
}

$conn->close();
?>
