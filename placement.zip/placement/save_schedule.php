<?php 
    require_once('dbconfig.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

    if($_SERVER['REQUEST_METHOD'] !='POST'){
        echo "<script> alert('Error: No data to save.'); location.replace('placement_main.php') </script>";
        $conn->close();
        exit;
    }
    

    extract($_POST);
	
    $allday = isset($allday);
	

    if(empty($id)){
        $sql = "INSERT INTO `schedule_list` (`company_name`,`dept`,`batch`,`test_type`,`date`) VALUES ('$company_name','$dept','$batch','$test_type','$date')";
    }else{
        $sql = "UPDATE `schedule_list` set `company_name` = '{$company_name}', `dept` = '{$dept}', `batch` = '{$batch}', `test_type` = '{$test_type}',`date` = '{$date}' where `id` = '{$id}'";
    }

    $save = $conn->query($sql);

    if($save){
        echo "<script> alert('Schedule Successfully Saved.'); location.replace('placement_main.php') </script>";
    }else{
        echo "<pre>";
        echo "An Error occured.<br>";
        echo "Error: ".$conn->error."<br>";
        echo "SQL: ".$sql."<br>";
        echo "</pre>";
    }
    
    $conn->close();
?>