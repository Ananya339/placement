<?php
$server="localhost";
$user="root";
$password="";
$db="placement_web";
$conn=mysqli_connect($server,$user,$password,$db);
if(!$conn)
{echo "Connection Failure ";
}
else
{
	echo "";
}
?>