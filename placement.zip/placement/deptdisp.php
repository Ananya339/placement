<?php
include "dbconfig.php";
?>
<!-- Add insert into table option-->
<!--<form action="search.php" method="POST" enctype="multipart/form-data" >-->
   <div class="search-container">
        <h1>DEPARTMENT PLACED STUDENT DETAILS</h1>
        <form action="" method="POST">
            <input type="text" placeholder="Search" name="search" required>
            <input type="submit" value="Search" name="submit">
            <button>
                <i class="fa fa-search" style="font-size: 18px;"></i>
            </button>
        </form>
    </div>
<?php
include "dbconfig.php";
if(isset($_POST['search'])) {
    $search = $_POST['search'];
    $search = preg_replace("#[^0-9a-z]i#","", $search);
$sql = "SELECT o.id_no, s.Name, s.Dept, o.USN, o.CompanyName, o.Package, o.offer_letter
        FROM offerform o
        INNER JOIN student s ON o.USN = s.USN WHERE o.id_no LIKE '%$search%' or s.name LIKE '%$search%' or s.Dept LIKE '%$search%'or o.USN LIKE '%$search%' or o.CompanyName LIKE '%$search%' or o.Package LIKE '%$search%'";
    $query = mysqli_query($conn,$sql);
    $count = mysqli_num_rows($query);
	 if($count == 0){
      echo "There was no search results!";
    }else{
		echo "<table><tr><th>ID</th><th>Student Name</th><th>Department</th><th>USN</th><th>Company Name</th><th>Package</th><th>OfferLetter</th></tr>";
  // output data of each row
  $counter = 1;
  while($row = mysqli_fetch_array($query)) {
    echo "<tr><td>" . $counter . "</td><td>".$row["Name"]."</td><td>".$row["Dept"]."</td><td>".$row["USN"]."</td><td>".$row["CompanyName"]."</td><td>".$row["Package"]."</td><td><a href='" . $row["offer_letter"] . "' target='_blank'>View Offer Letter</a></td></tr>";
  }
  echo "</table>";
}
}
else{
// Display placement data
$sql1 = "SELECT o.id_no, s.Name, s.Dept, o.USN, o.CompanyName, o.Package, o.offer_letter
        FROM offerform o
        INNER JOIN student s ON o.USN = s.USN";

$result = mysqli_query($conn, $sql1);
if(mysqli_num_rows($result)>0)
{
        echo "<table>
            <tr>
                        <th>Sl. No</th>
                        <th>Name</th>
                        <th>USN</th>
                        <th>Branch</th>
                        <th>Company Name</th>
                        <th>Salary</th>
                        <th>Offer Letter</th>
                    </tr>";
					$counter = 1;
        while($row=mysqli_fetch_assoc($result))
	{
		echo"<tr>
		<td>" . $counter . "</td>
                            <td>" . $row["Name"] . "</td>
                            <td>" . $row["USN"] . "</td>
                            <td>" . $row["Dept"] . "</td>
                            <td>" . $row["CompanyName"] . "</td>
                            <td>" . $row["Package"] . "</td>
                            <td><a href='" . $row["offer_letter"] . "' target='_blank'>View Offer Letter</a></td>

		</tr>";
	}
}
	echo"</table>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department Display</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 50px;
            max-height: 50px;
        }

        .search-container {
            text-align: right;
        }

        h1 {
            text-align: center;
        }
    </style>
</head>

<body>
<button onclick="window.print()">Print this page</button>

</body>

</html>

<?php
$conn->close();
?>
