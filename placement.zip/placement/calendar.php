<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Schedule</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.css">

    <style>
<!--:root {
            --bs-success-rgb: 71, 222, 152 !important;
        }-->

        html,
        body {
            height: 100%;
            width: 100%;
            font-family: Apple Chancery, cursive;
        }

        .btn-info.text-light:hover,
        .btn-info.text-light:focus {
            background: #000;
        }
        table, tbody, td, tfoot, th, thead, tr {
            border-color: #ededed ;
            border-style: solid;
            border-width: 1px !important;
        }
        .title{
            font-size: 30px;
        }
    </style>
</head>
<body class="bg-light">

    <?php
        require_once('dbconfig.php');

        $schedules = $conn->query("SELECT * FROM `schedule_list`");
        $sched_res = [];

foreach($schedules->fetch_all(MYSQLI_ASSOC) as $row){
            /*$row['date'] = date(strtotime($row['date']));*/
            $sched_res[$row['id']] = $row;
        }

        if(isset($conn)) $conn->close();
    ?>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark bg-gradient" id="topNavBar">
        <div class="container d-flex justify-content-center">
            <div class="row">
                <div class="col-md-12">
                    <a class="navbar-brand title" href="#">Student Schedule</a>
                </div>
            </div>
        </div>
    </nav>
    <div class="container py-5" id="page-container">
        <div class="row">
            <div class="col-md-9">
                <div id="calendar"></div>
            </div>
            <div class="col-md-3">
                <div class="cardt rounded-0 shadow">
                    <div class="card-header bg-gradient bg-primary text-light">
                        <h5 class="card-title">Company Visit Form</h5>
                    </div>
                    <div class="card-body">
                        <div class="container-fluid">
                            <form action="save_schedule.php" method="post" id="schedule-form">
                                <input type="hidden" name="id" value="">
                                <div class="form-group mb-2">
                                    <label for="company_name" class="control-label">Company Name</label>
                                    <input type="text" class="form-control form-control-sm rounded-0" name="company_name" id="company_name" required>
                                </div>
                                <div class="form-group mb-2">
                                    <label for="dept" class="control-label">Department</label>
                                    <select name="dept" id="dept" required>
                <option value="CSE">CSE</option>
                <option value="CSE(AIML)">CSE(AIML)</option>
                <option value="CSE(AI&DS)">CSE(AIDS)</option>
                <option value="ISE">ISE</option>
				<option value="ECE">ECE</option>
				<option value="EEE">EEE</option>
				<option value="CSE,CSE(AIML),CSE(AI&DS),ISE,ECE,EEE">All The Dept.</option>
				</select>
                                </div>
								                                <div class="form-group mb-2">
                                    <label for="batch" class="control-label">Batch</label>
                                    <input type="number" name="batch" id="batch" min="2024" max="2050" required>
                                </div>
								<div class="form-group mb-2">
								 <label for="test_type" class="control-label">Test Type</label>
                                    <select name="test_type" id="test_type" required>
<option value="Internship - Online test">Internship - Online test</option>
				<option value="Internship - Online test">Internship - Interview</option>
				<option value="Campus Hiring - Online Test">Campus Hiring - Online Test</option>
                <option value="Campus Hiring - Interviews">Campus Hiring - Interviews</option>
                
            </select>
                                </div>
                                <div class="form-group mb-2">
                                    <label for="date" class="control-label">Date</label>
                                    <input type="date" name="date" id="date" pattern="\d{4}-\d{2}-\d{2}" required>
                                </div>
                         
                            </form>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="text-center">
                            <button class="btn btn-primary btn-sm rounded-0" type="submit" form="schedule-form"><i class="fa fa-save"></i> Save</button>
                            <button class="btn btn-default border btn-sm rounded-0" type="reset" form="schedule-form"><i class="fa fa-reset"></i> Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Event Details Modal -->
    <div class="modal fade" tabindex="-1" data-bs-backdrop="static" id="event-details-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-0">
                <div class="modal-header rounded-0">
                    <h5 class="modal-title">Schedule Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body rounded-0">
                    <div class="container-fluid">
                        <dl>
                            <dt class="text-muted">Company Name</dt>
                            <dd id="company_name" class="fw-bold fs-4"></dd>
                            <dt class="text-muted">Department</dt>
                            <dd id="dept" class=""></dd>
                            <dt class="text-muted">Batch</dt>
                            <dd id="batch" class=""></dd>
                            <dt class="text-muted">Test type</dt>
                            <dd id="test_type" class=""></dd>
							<dt class="text-muted">Date</dt>
                            <dd id="date" class=""></dd>
                        </dl>
                    </div>
                </div>
                <div class="modal-footer rounded-0">
                    <div class="text-end">
                        <button type="button" class="btn btn-primary btn-sm rounded-0" id="edit" data-id="">Edit</button>
                        <button type="button" class="btn btn-danger btn-sm rounded-0" id="delete" data-id="">Delete</button>
                        <button type="button" class="btn btn-secondary btn-sm rounded-0" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.js"></script>
    <script src="script.js"></script>
    <script>
        var scheds = $.parseJSON('<?= json_encode($sched_res) ?>')
    </script>
</body>
</html>